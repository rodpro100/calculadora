@echo off
rem Calculadora: se abre en su propia ventana y crea un acceso directo en el escritorio
cd /d "%~dp0"
powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command ^
 "$d=(Get-Location).Path; $u=([Uri](Join-Path $d 'index.html')).AbsoluteUri;" ^
 "$b=@(\"${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe\",\"$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe\",\"$env:ProgramFiles\Google\Chrome\Application\chrome.exe\",\"$env:LocalAppData\Google\Chrome\Application\chrome.exe\") | Where-Object { Test-Path $_ } | Select-Object -First 1;" ^
 "$lnk=Join-Path ([Environment]::GetFolderPath('Desktop')) 'Calculadora.lnk';" ^
 "if($b){ $s=(New-Object -ComObject WScript.Shell).CreateShortcut($lnk); $s.TargetPath=$b; $s.Arguments=('--app=\"'+$u+'\" --window-size=1200,760'); $s.IconLocation=(Join-Path $d 'icono.ico'); $s.WorkingDirectory=$d; $s.Description='Calculadora'; $s.Save() }" ^
 "if($b){ Start-Process $b -ArgumentList ('--app=\"'+$u+'\"','--window-size=1200,760') } else { Start-Process (Join-Path $d 'index.html') }"
if errorlevel 1 start "" "%~dp0index.html"
